# tar-strip
-----

Node.js implementation of `tar` command's `strip-components` option 

```
--strip-components=NUMBER
           strip NUMBER leading components from file names on extraction
```

tar-strip/
tar-strip/README.md